# Design System Strategy: The Editorial Monolith

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Digital Atelier."** We are not building a generic e-commerce site; we are crafting a digital flagship store that mirrors the experience of walking into a high-end Lagos beauty boutique. 

To achieve this, the system moves away from "boxed" layouts. We embrace **Editorial Asymmetry**, where typography serves as the primary visual anchor rather than imagery. By leveraging large-scale Noto Serif headlines and intentional whitespace, we create a sense of "Quiet Luxury." The design breaks the standard grid by using overlapping text elements and staggered content blocks, ensuring the Nigerian market perceives a brand that is both authoritative and avant-garde.

## 2. Colors & Surface Philosophy
The color palette is rooted in the depth of `primary` (#2e0052) and `primary_container` (#4b0082). These are high-pigment tones that command respect and signify premium quality.

*   **The "No-Line" Rule:** 1px solid borders are strictly prohibited for sectioning. We define space through "Tonal Carving." A section transition is achieved by moving from `surface` (#f9f9ff) to `surface_container_low` (#f3f3fa). This creates a soft, sophisticated edge that feels like folded silk rather than a wireframe.
*   **Surface Hierarchy & Nesting:** Treat the UI as a physical stack.
    *   **Level 0 (Base):** `surface`
    *   **Level 1 (Sections):** `surface_container_low`
    *   **Level 2 (Interactive Cards):** `surface_container_lowest` (Pure White)
*   **The "Glass & Gradient" Rule:** For floating elements (navigation bars or service modals), use a 60% opacity of `surface` with a `backdrop-blur` of 20px. 
*   **Signature Textures:** For primary CTAs, do not use flat hex codes. Apply a subtle linear gradient from `primary` (#2e0052) to `primary_container` (#4b0082) at a 135-degree angle. This adds "ink-like" depth to the UI.

## 3. Typography
Typography is the "Hero" of this system. We use it to create structure and emotion in the absence of photography.

*   **Display (Noto Serif):** Used for the "Image-less" Hero section. Use `display-lg` with a tight `letter-spacing: -0.02em` to create a monolithic, high-fashion impact.
*   **Headlines (Noto Serif):** These function as the "Curator’s Voice." Use `headline-lg` for service categories. It should feel literary and intentional.
*   **Body & Titles (Public Sans):** A clean, geometric sans-serif that provides a "Clinical Precision" to the luxury aesthetic. Public Sans’s high x-height ensures readability on high-resolution mobile devices common in the Nigerian market.
*   **Labels (Work Sans):** Use `label-md` in `all-caps` with `letter-spacing: 0.1em` for metadata and small tags to maintain an editorial feel.

## 4. Elevation & Depth
We eschew "Material" shadows in favor of **Ambient Luminosity.**

*   **The Layering Principle:** Depth is achieved by placing `surface_container_lowest` (#ffffff) elements atop `surface_container` (#ededf4) backgrounds. The contrast between the two is the "Shadow."
*   **Ambient Shadows:** If a card must float (e.g., a "Book Now" floating action button), use a shadow color derived from `on_surface` (#191c20) at 6% opacity, with a 32px blur and 16px Y-offset. It should look like a soft glow, not a dark smudge.
*   **The "Ghost Border":** For input fields or subtle containers, use `outline_variant` (#cec3d3) at 20% opacity. If it looks like a line, it’s too dark. It should look like a "haze."

## 5. Components

### Buttons
*   **Primary:** Background: `primary` gradient; Text: `on_primary`; Roundedness: `none` (0px) for a sharp, architectural look.
*   **Secondary:** Background: `transparent`; Border: 1px Ghost Border (`outline_variant` @ 20%); Text: `primary`.
*   **State:** On hover/active, shift the background to `primary_container`.

### Input Fields
*   **Styling:** No background. Only a bottom border (1px) using `outline`.
*   **Labels:** Always use `label-md` in `primary` color above the input. When focused, the bottom border thickens to 2px using `primary`.

### Service Cards
*   **Structure:** No dividers. Use `spacing-8` (2.75rem) to separate the service title from the price. 
*   **Background:** Use `surface_container_low`. On hover, transition to `surface_container_highest`.

### Hero Typography Block (No-Image Hero)
*   **Composition:** Use `display-lg` for the main hook. Use a "Hanging Punctuation" style where the serif quotes or accents sit in the margin. Surround with `spacing-24` (8.5rem) of whitespace to force focus onto the brand message.

### Chips (Beauty Tags)
*   **Style:** `surface_container_high` background with `on_surface_variant` text. Roundedness: `full` (9999px) to contrast against the sharp-edged buttons.

## 6. Do's and Don'ts

### Do:
*   **DO** use extreme vertical whitespace (`spacing-16` or `spacing-20`) between sections to create a "Gallery" feel.
*   **DO** use `primary` for all primary Call-to-Actions to ensure high contrast for the Nigerian user base.
*   **DO** mix font weights—pair a `display-lg` (Noto Serif Regular) with a `label-md` (Work Sans Bold) for a sophisticated hierarchy.

### Don’t:
*   **DON’T** use icons for everything. Let the typography speak. Only use icons for essential utility (Cart, User, Search).
*   **DON’T** use standard grey shadows. Shadows must always have a hint of the `primary` purple hue to feel "on-brand."
*   **DON’T** use 100% black. Use `on_surface` (#191c20) for text to keep the "ink" look soft and premium.
*   **DON’T** use dividers. If two pieces of content feel cluttered, add more whitespace from the `Spacing Scale`, don't add a line.